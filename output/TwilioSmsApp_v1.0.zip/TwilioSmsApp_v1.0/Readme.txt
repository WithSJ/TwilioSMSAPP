[First Time Install]
just run "install.bat" file only need once when you start app first time in computer
it's black console window auto close when it's completly create shotcut
*************************************************************************

Start APP

Step1: run "StartDomainServer.bat" [don't close black console window]
Step2: run "TwilioSmsAppServer.exe" [don't close black console window]
Step3: start TwilioSmsApp 

**************************************************************************

StartDomainServer use to make server online so when you need to put Server_URL  in the app use find url from it.

Example URL (https://facb7fe3b4c0b0.lhrtunnel.link)

[first time it's ask for create connection type "yes" to continue]
**************************************************************************

TwilioSmsAppServer it's server program don't close it while using sms app.

**************************************************************************




